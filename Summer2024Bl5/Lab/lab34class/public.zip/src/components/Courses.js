const Courses = [
  { id: "1", name: "Java" },
  { id: "2", name: "English" },
  { id: "3", name: "Japanese" },
];
export default Courses;
