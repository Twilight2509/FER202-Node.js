const Qualities = ["Very good", "Good", "Normal", "Bad"];
export default Qualities;
