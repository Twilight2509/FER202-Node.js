function App(){
    return (
        <div>FER202 - Practical Exam given</div>
    )
}

export default App;